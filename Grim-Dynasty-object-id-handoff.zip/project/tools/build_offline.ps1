param([string]$OutputDirectory='D:\MyGitRepo\Grim-Dynasty\.tooling\offline-system')
$ErrorActionPreference='Stop'
$project=[IO.Path]::GetFullPath('D:\MyGitRepo\Grim-Dynasty')
$target=[IO.Path]::GetFullPath($OutputDirectory)
if(!$target.StartsWith($project+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must remain in project'}
$manifestPath=Join-Path $target 'manifest.json'
if(Test-Path -LiteralPath $target){
 if(!(Test-Path -LiteralPath $manifestPath)){throw 'Existing output is not owned by this build; preserving it'}
 $previous=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
 if($previous.owner -ne 'GrimDynastyOfflineBuild-v1'){throw 'Unknown output owner; preserving'}
 foreach($property in $previous.files.PSObject.Properties){
  $p=Join-Path $target $property.Name
  if(!(Test-Path -LiteralPath $p) -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() -ne $property.Value){throw "Output changed since prior build: $($property.Name); preserving it"}
 }
}
$steps=@(
 'src\resource_codec\build_containers.ps1',
 'src\quest_codec\build_quests.ps1',
 'src\condition_logic\build_conditions.ps1',
 'src\task_logic\build_tasks.ps1',
 'src\token_actions\build_token_actions.ps1',
 'src\task_runtime\build_runtime.ps1',
 'src\task_auto\build_auto.ps1',
 'src\task_kills\build_kills.ps1',
 'src\task_items\build_items.ps1',
 'src\rewards\build_rewards.ps1'
)
foreach($step in $steps){& (Join-Path $project $step);if(!$?){throw "Build step failed: $step"}}
$files=[ordered]@{}
foreach($name in @('Resources','Quests','Conditions','TaskLogic','TokenActions','TaskRuntime','TaskAuto','TaskKills','TaskItems','Rewards')){$files["GrimDynasty.$name.dll"]=Join-Path $project ".tooling\rewards-build\GrimDynasty.$name.dll"}
foreach($item in @(
 @('TaskRuntimeDemo.exe','task-runtime-build'),
 @('AutoQuestDemo.exe','task-auto-build'),
 @('KillQuestDemo.exe','task-kills-build'),
 @('ItemQuestDemo.exe','task-items-build'),
 @('RewardQuestDemo.exe','rewards-build'),
 @('AdjustedQuestDemo.exe','rewards-build'),
 @('ExperienceQuestDemo.exe','rewards-build'),
 @('LevelUpQuestDemo.exe','rewards-build'),
 @('CrtLevelUpQuestDemo.exe','rewards-build'),
 @('TutorialQuestDemo.exe','rewards-build'),
 @('AcceptQuestDemo.exe','rewards-build'),
 @('ItemAcceptQuestDemo.exe','rewards-build'),
 @('InventoryDeliveryDemo.exe','rewards-build'),
 @('FullInventoryDeliveryDemo.exe','rewards-build'),
 @('InventoryRoundTripDemo.exe','rewards-build'),
 @('RuntimeIdInventoryDemo.exe','rewards-build'),
 @('CrtCurveCatalogProbe.exe','rewards-build'),
 @('MoneyCatalogProbe.exe','rewards-build'),
 @('ItemAutoCatalogProbe.exe','task-items-build'),
 @('ItemCatalogProbe.exe','task-items-build'),
 @('KillCatalogProbe.exe','task-kills-build'),
 @('QuestProbe.exe','quest-definition-build'),
 @('ResourceProbe.exe','resource-containers-build')
)){$files[$item[0]]=Join-Path $project ".tooling\$($item[1])\$($item[0])"}
if(!(Test-Path -LiteralPath $target)){New-Item -ItemType Directory -Path $target | Out-Null}
foreach($name in $files.Keys){
 $destination=Join-Path $target $name
 if((Test-Path -LiteralPath $destination) -and (!(Test-Path -LiteralPath $manifestPath) -or !($previous.files.PSObject.Properties.Name -contains $name))){throw "Unowned output collision: $name"}
 Copy-Item -LiteralPath $files[$name] -Destination $destination -Force
}
$hashes=[ordered]@{};$dependencies=[ordered]@{}
foreach($name in $files.Keys){
 $path=Join-Path $target $name;$hashes[$name]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
 if($name.EndsWith('.dll')){
  $refs=@([Reflection.Assembly]::LoadFile($path).GetReferencedAssemblies() | ForEach-Object {$_.Name})
  foreach($reference in $refs){if($reference -eq 'Game' -or $reference -eq 'Engine' -or $reference -like '*Steam*'){throw "Original dependency detected: $reference"};if($reference -like 'GrimDynasty.*' -and !($files.Keys -contains "$reference.dll")){throw "Missing own dependency: $reference"}}
  $dependencies[$name]=$refs
 }
}
foreach($name in @('TaskRuntimeDemo.exe','AutoQuestDemo.exe','KillQuestDemo.exe','ItemQuestDemo.exe','RewardQuestDemo.exe','AdjustedQuestDemo.exe','ExperienceQuestDemo.exe','LevelUpQuestDemo.exe','CrtLevelUpQuestDemo.exe','TutorialQuestDemo.exe','AcceptQuestDemo.exe','ItemAcceptQuestDemo.exe','InventoryDeliveryDemo.exe','FullInventoryDeliveryDemo.exe','InventoryRoundTripDemo.exe','RuntimeIdInventoryDemo.exe')){& (Join-Path $target $name);if($LASTEXITCODE -ne 0){throw "Packaged demo failed: $name"}}
$record=[ordered]@{owner='GrimDynastyOfflineBuild-v1';utc=[DateTime]::UtcNow.ToString('o');status='passed';modules=10;native_math_provider=[ordered]@{path='C:\Windows\System32\ucrtbase.dll';sha256='3c60056371f82e4744185b6f2fa0c69042b1e78804685944132974dd13f3b6d9';scope='Optional verified Windows10 x64 System32 CRT, explicit C-locale and unchanged floating control. No original installation DLL.'};files=$hashes;dependencies=$dependencies;scope='Own managed DLLs and own original fixtures. Build/demos need no original game DLL, resources, Steam, saves, network or new SDK. Catalog tools only read authorized resources when explicitly invoked.'}
$json=$record | ConvertTo-Json -Depth 8
if(Test-Path -LiteralPath $manifestPath){$backup=Join-Path $target ('manifest.'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffff')+'.json');Copy-Item -LiteralPath $manifestPath -Destination $backup -ErrorAction Stop}
$pending=Join-Path $target 'manifest.pending.json'
if(Test-Path -LiteralPath $pending){throw 'Pending manifest exists; preserving'}
[IO.File]::WriteAllText($pending,$json,[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $pending -Destination $manifestPath -Force
Write-Output "Built and verified ten own modules and sixteen standalone scenario CLIs at $target"
